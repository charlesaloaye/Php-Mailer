
<?php
$appname = "Php mailer Script";
$dev = "Sedenu Aloaye charles";
$dev_url ="http://fb.com/sedenu.charles";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>
<?php echo $appname; ?>
</title>
<meta charset="UTF-8">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta name="viewport" content="width=device-width, user-scalable=no,maximum-scale=1,initial-scale=1">
 <link href="Css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="Css/mail.css"  type="text/css" rel="stylesheet">
</head>