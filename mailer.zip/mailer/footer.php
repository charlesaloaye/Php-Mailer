<div class="container">
<footer class="pull-right">
design by <font color="red"> &hearts; </font> <a href="
<?php echo $dev_url; ?>"><?php echo $dev; ?></a> &copy; 2017-<?php echo date("Y");?>
</footer>
</div>